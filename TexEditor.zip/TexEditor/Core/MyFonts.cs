﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Core
{
	public class MyFonts
	{
		//string name;
		//int size;
		//Color color;
		//string name_brushes;
		//Brush brush;
		//public MyFonts(string name, int size, Color col, string brush_name)
		//{
		//	this.name = name;
		//	this.size = size;
		//	this.color = col;		
		//	this.name_brushes = brush_name;
		//	Brush = new SolidBrush(col);
		//}

	
		//public bool Equals(MyFonts obj)
		//{
		//	return
		//		obj.name == name &&
		//		obj.size == size;
		//}


		//public string Name { get => name; set => name = value; }
		//public int Size { get => size; set => size = value; }

		//public string Name_brushes { get => name_brushes; set => name_brushes = value; }

		//public Color Colors { get => color; set => color = value; }
		//public Brush Brush { get => brush; set => brush = value; }
	}
}
