﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Media;

namespace TexEditor
{
	public class MyFonts
	{
		string name;
		int size;
		string name_brushes;
		Brush brush;
		public MyFonts(string name, int size, Brush brush, string brush_name)
		{
			this.name = name;
			this.size = size;		
			this.name_brushes = brush_name;
			this.brush = brush;
		}


		public bool Equals(MyFonts obj)
		{
			return
				obj.name == name &&
				obj.size == size;
		}


		public string Name { get => name; set => name = value; }
		public int Size { get => size; set => size = value; }

		public string Name_brushes { get => name_brushes; set => name_brushes = value; }

		public Brush Brush { get => brush; set => brush = value; }
	}




	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		List<MyFonts> all_fonts;
		public MainWindow()
		{

			InitializeComponent();
			all_fonts = new List<MyFonts>();
			all_fonts.Add(new MyFonts("Calibri", 8, Brushes.Black, "Black"));
			all_fonts.Add(new MyFonts("Times New Roman", 10, Brushes.Red, "Red"));
			all_fonts.Add(new MyFonts("ZapfEllipt BT", 12, Brushes.Green, "Green"));
			all_fonts.Add(new MyFonts("Harlow Solid Italic", 14, Brushes.DarkBlue, "DarkBlue"));
			all_fonts.Add(new MyFonts("Mona Lisa Solid ITC TT", 16, Brushes.Beige, "Beige"));
			all_fonts.Add(new MyFonts("Jive Modern", 18, Brushes.Cyan, "Cyan"));
			all_fonts.Add(new MyFonts("Lucida Bright", 20, Brushes.Brown, "Brown"));
			cmbFont.ItemsSource = all_fonts;
			cmbFontsNames.ItemsSource = all_fonts;
			cmbdFontColors.ItemsSource = all_fonts;
		}

		private void checkbx_Checked(object sender, RoutedEventArgs e)
		{
		
			txbEnd.IsEnabled = true;
			txbStart.IsEnabled = true;


		}

		private void checkbx_Unchecked(object sender, RoutedEventArgs e)
		{
			txbEnd.IsEnabled = false;
			txbStart.IsEnabled = false;		
		}




		private void Window_SizeChanged_1(object sender, SizeChangedEventArgs e)
		{
			richbox.Width = this.ActualWidth - 25-expand.ActualWidth;
		
		}

		private void btnClear_Click(object sender, RoutedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
				richbox.Selection.ClearAllProperties();
		}

		private void btnBold_Click(object sender, RoutedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
				richbox.Selection.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
		}

		private void btnItalic_Click(object sender, RoutedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
				richbox.Selection.ApplyPropertyValue(TextElement.FontStyleProperty, FontStyles.Italic);
		}

		private void btnUnderline_Click(object sender, RoutedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
			{

				Underline underline = new Underline(richbox.Selection.Start, richbox.Selection.End);
			}
		}

		private void cmbFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
			{
				int values = all_fonts[cmbFont.SelectedIndex].Size;
				richbox.Selection.ApplyPropertyValue(TextElement.FontSizeProperty, (double)values);
			}

		}

		private void cmbdFontColors_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!richbox.Selection.IsEmpty)
				richbox.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, all_fonts[cmbdFontColors.SelectedIndex].Brush);
			
		}

		private void cmbFontsNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{

			if (!richbox.Selection.IsEmpty)
				richbox.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, all_fonts[cmbFontsNames.SelectedIndex].Name);
		}





		TextPointer FindPointerAtTextOffset(TextPointer from, int offset, bool seekStart)
		{
			if (from == null)
				return null;

			TextPointer current = from;
			TextPointer end = from.DocumentEnd;
			int charsToGo = offset;

			while (current.CompareTo(end) != 0)
			{
				Run currentRun;
				if (current.GetPointerContext(LogicalDirection.Forward) == TextPointerContext.Text &&
					(currentRun = current.Parent as Run) != null)
				{
					var remainingLengthInRun = current.GetOffsetToPosition(currentRun.ContentEnd);
					if (charsToGo < remainingLengthInRun ||
						(charsToGo == remainingLengthInRun && !seekStart))
						return current.GetPositionAtOffset(charsToGo);
					charsToGo -= remainingLengthInRun;
					current = currentRun.ElementEnd;
				}
				else
				{
					current = current.GetNextContextPosition(LogicalDirection.Forward);
				}
			}
			if (charsToGo == 0 && !seekStart)
				return end;
			return null;
		}







		private void btnstart_Click(object sender, RoutedEventArgs e)
		{
			if (txbStart.Text.Length > 0 && txbEnd.Text.Length > 0)
			{
				int.TryParse(txbStart.Text, out int start);
				int.TryParse(txbEnd.Text, out int end);
				TextRange s = new TextRange(richbox.Document.ContentStart, richbox.Document.ContentEnd);


				//0 не разрешаю вводить тк позиция пользовательского отсчета символов идет с 1
				if (end < 1 || start < 1 || start > end || end < start || start + 1 > s.Text.Length || end + 2 > s.Text.Length || end == 0 && start == 0)
				{
					btnBold.IsEnabled = false;
					btnClear.IsEnabled = false;
					btnItalic.IsEnabled = false;
					btnUnderline.IsEnabled = false;
					cmbdFontColors.IsEnabled = false;
					cmbFont.IsEnabled = false;
					cmbFontsNames.IsEnabled = false;
					System.Windows.Forms.MessageBox.Show("Wrong input params");
					return;
				}
				else
				{
					if (btnBold.IsEnabled == false)
					{
						btnBold.IsEnabled = true;
						btnClear.IsEnabled = true;
						btnItalic.IsEnabled = true;
						btnUnderline.IsEnabled = true;
						cmbdFontColors.IsEnabled = true;
						cmbFont.IsEnabled = true;
						cmbFontsNames.IsEnabled = true;
					}
				}


				var flowDocument = richbox.Document;
				TextPointer start1 = FindPointerAtTextOffset(flowDocument.ContentStart, start-1, seekStart: true);
				if (start1 == null)
				{
					// позиция вне документа, выходим
					return;
				}

				TextPointer end1 = FindPointerAtTextOffset(
						start1, end - start+1, seekStart: false);
				if (end1 == null)
				{
					// позиция вне документа, выходим
					return;
				}

				richbox.Selection.Select(start1, end1);
				richbox.Focus();
			}
			else System.Windows.Forms.MessageBox.Show("Empty fields");
		}

		private void expand_Expanded(object sender, RoutedEventArgs e)
		{
			richbox.Width = this.ActualWidth - 35 - toolbartr.Width-expand.Width;
			richbox.UpdateLayout();
		}

		private void expand_Collapsed(object sender, RoutedEventArgs e)
		{
			richbox.Width = this.ActualWidth - 35 - toolbartr.Width;
		}
	}
}
